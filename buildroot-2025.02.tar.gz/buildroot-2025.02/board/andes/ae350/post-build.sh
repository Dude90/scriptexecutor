#!/bin/sh
cp $BINARIES_DIR/Image $TARGET_DIR/boot
cp $BINARIES_DIR/ae350_ax45mp.dtb $TARGET_DIR/boot
