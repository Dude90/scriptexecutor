Run the emulation with:

 qemu-system-or1k -kernel output/images/vmlinux -nographic # qemu_or1k_defconfig

The login prompt will appear in the terminal that started Qemu.
